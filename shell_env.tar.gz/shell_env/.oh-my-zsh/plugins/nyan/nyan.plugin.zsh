if [[ -x `which nc` ]]; then
  alias nyan='nc -v nyancat.dakko.us 23' # nyan cat
fi


