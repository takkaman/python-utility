Droid Sans Mono for Powerline
=============================

:Font creator: Ascender Corporation
:Source: Provided by system
:Patched by: `mt3 <https://github.com/mt3>`_
